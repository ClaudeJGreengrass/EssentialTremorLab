  #include "UserTypes.h"
// User data functions.  Modify these functions for your data items.

// Start time for data
static uint32_t startMicros;

// Adafruit inline code

// union of 2 uint16_t and a float
// used to move between sensor data and ExFatLogger data
union i_a_o in_and_out;

#include <Adafruit_LSM6DS33.h>

Adafruit_LSM6DS33 lsm6ds33;
// Adafruit ends

// Acquire a data record.
void acquireData(data_t* data) {
  // Adafruit inline code
  sensors_event_t accel;
  sensors_event_t gyro;
  sensors_event_t temp;
  // Adafruit ends

  data->time = micros();
  
/*  for (int i = 0; i < ADC_DIM; i++) {
    data->adc[i] = analogRead(i);
  } */

    // Adafruit inline code
    lsm6ds33.getEvent(&accel, &gyro, &temp);
    // Store the acceleratomter 'X' data for logging
    in_and_out.sensorData = accel.acceleration.x;
    data->adc[0] = in_and_out.EFLdata[0];
    data->adc[1] = in_and_out.EFLdata[1];

    in_and_out.sensorData = accel.acceleration.y;
    data->adc[2] = in_and_out.EFLdata[0];
    data->adc[3] = in_and_out.EFLdata[1];

    in_and_out.sensorData = accel.acceleration.z;
    data->adc[4] = in_and_out.EFLdata[0];
    data->adc[5] = in_and_out.EFLdata[1];

    // Now the gyro data

    in_and_out.sensorData = gyro.gyro.x;
    data->adc[6] = in_and_out.EFLdata[0];
    data->adc[7] = in_and_out.EFLdata[1];

    in_and_out.sensorData = gyro.gyro.y;
    data->adc[8] = in_and_out.EFLdata[0];
    data->adc[9] = in_and_out.EFLdata[1];
   
    in_and_out.sensorData = gyro.gyro.z;
    data->adc[10] = in_and_out.EFLdata[0];
    data->adc[11] = in_and_out.EFLdata[1];

    // Adafruit ends

}

// Print a data record.
void printData(Print* pr, data_t* data) {
  if (startMicros == 0) {
    startMicros = data->time;
  }
  pr->print(data->time - startMicros);
/*
  for (int i = 0; i < ADC_DIM; i++) {
    pr->write(',');
    pr->print(data->adc[i]);
  }
*/
    // Adafruit inline code
      
    // first the accelerometer data
    in_and_out.EFLdata[0] = data->adc[0];
    in_and_out.EFLdata[1] = data->adc[1];
    pr->write(',');
    pr->print(in_and_out.sensorData, 3);

    in_and_out.EFLdata[0] = data->adc[2];
    in_and_out.EFLdata[1] = data->adc[3];
    pr->write(',');
    pr->print(in_and_out.sensorData, 3);

    in_and_out.EFLdata[0] = data->adc[4];
    in_and_out.EFLdata[1] = data->adc[5];
    pr->write(',');
    pr->print(in_and_out.sensorData, 3);

    // then the gyro data
    in_and_out.EFLdata[0] = data->adc[6];
    in_and_out.EFLdata[1] = data->adc[7];
    pr->write(',');
    pr->print(in_and_out.sensorData, 3);

    in_and_out.EFLdata[0] = data->adc[8];
    in_and_out.EFLdata[1] = data->adc[9];
    pr->write(',');
    pr->print(in_and_out.sensorData, 3);

    in_and_out.EFLdata[0] = data->adc[10];
    in_and_out.EFLdata[1] = data->adc[11];
    pr->write(',');
    pr->print(in_and_out.sensorData, 3);
    // ends Adafruit


  pr->println();
}

// Print data header.
void printHeader(Print* pr) {
  startMicros = 0;
  
  pr->print(F("micros"));
/*
  for (int i = 0; i < ADC_DIM; i++) {
    pr->print(F(",adc"));
    pr->print(i);
  }
*/
  pr->print(F(",Acc X,Acc Y, Acc Z,Gyro X, Gyro Y, Gyro Z"));
  pr->println();
}

// Sensor setup
void userSetup() {
  // Adafruit inline code
  if (!lsm6ds33.begin_I2C()) {
    Serial.println(F("Failed to find LSM6DS33 chip"));
    while (1) {
      delay(10);
    }
  }
Serial.println(F("found LSM6DS33 chip"));
  lsm6ds33.configInt1(false, false, true); // accelerometer DRDY on INT1
  lsm6ds33.configInt2(false, true, false); // gyro DRDY on INT2
//  lsm6ds33.setAccelDataRate(LSM6DS_RATE_833_HZ);
//  lsm6ds33.setGyroDataRate(LSM6DS_RATE_833_HZ);
  lsm6ds33.setAccelDataRate(LSM6DS_RATE_1_66K_HZ);
  lsm6ds33.setGyroDataRate(LSM6DS_RATE_1_66K_HZ);

//LSM6DS3Sensor.writeReg(0x03, 0x04);
//lsm6ds33.highPassFilter(0x03, 0x04);
//LSM6DS3_ACC_GYRO_WriteReg(0x03, 0x04);
  // Adafruit ends
}
