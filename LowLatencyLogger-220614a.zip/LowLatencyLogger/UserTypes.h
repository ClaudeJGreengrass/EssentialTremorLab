#ifndef UserTypes_h
#define UserTypes_h
#include "Arduino.h"
// User data types.  Modify for your data items.
#define FILE_BASE_NAME "adc4pin"
const uint8_t ADC_DIM = 16; // (3 floats * 2 sensor * 4 bytes)/sizeof(type unit16_t) = 24/2
struct data_t {
  uint32_t time;
  uint16_t adc[ADC_DIM];
};

// union of 2 uint16_t and a float
// used to move between sensor data and LowLatencyLogger data
union i_a_o {
  float sensorData;
  uint16_t EFLdata[2];

}; // in_and_out;

void acquireData(data_t* data);
void printData(Print* pr, data_t* data);
void printHeader(Print* pr);
void userSetup();
#endif  // UserTypes_h
